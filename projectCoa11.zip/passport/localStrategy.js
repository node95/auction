var LocalStrategy = require('passport-local').Strategy;
var User = require('../schemas/user');
const bcrypt = require('bcrypt');

module.exports = function(passport)
{
  passport.use(new LocalStrategy({
    usernameField: 'id',
    passwordField: 'password'
  },
  function(id, password, done){
    User.findOne({userId: id}, (err, user) => {
      if(user){
        bcrypt.compare(password, user.userPwd, function(err, result) {
          if(result)
            return done(null, user);
          else
            return done(null, false, { message: '회원정보가 일치하지 않습니다.' });
        });
      }
      else
        return done(null, false, { message: '회원정보가 일치하지 않습니다.' });
    });
  }));
}
