var local = require('./localStrategy');
var User = require('../schemas/user');

module.exports = (passport) => {
  passport.serializeUser((user, done) => {
    done(null, user.userId);
  });

  passport.deserializeUser((id, done) => {
    User.findOne({userId: id}).populate("auction.product", "Topic")
      .then(user => done(null, user))
      .catch(err => done(err));
  });

  local(passport);
}
