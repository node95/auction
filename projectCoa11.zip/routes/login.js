var express = require('express');
var passport = require('passport');
var router = express.Router();

router.post('/process', function(req, res, next)
{
  passport.authenticate('local', function(err, user, info)
  {
    if(info)
      req.session.flash.error = [info.message];

    if(err)
      return next(err);
    if(!user){
      return req.session.save(function(err){
        if(err)
          return next(err);
        return res.redirect('/login');
      });
    }
    req.logIn(user, function(err){
      if(err)
        return next(err);
      return req.session.save(function(err){
        if(err)
          return next(err);
        return res.redirect('/');
      });
    });
  })(req, res, next);
});

module.exports = router;
