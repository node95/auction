var express = require('express');
const Product = require('../schemas/product');
const User = require('../schemas/user');

var router = express.Router();

router.post('/price', function (req, res, next) {
  Product.findOneAndUpdate({_id: req.query.num, "auction.user": req.user._id}, {$max: {startPrice: req.body.price}, $set: {"auction.$.bid": req.body.price}}, function(err, result){
    User.findOneAndUpdate({_id: req.user._id, "auction.product": req.query.num}, {$set: {"auction.$.bid": req.body.price}}, function(err, result2){
      if(result === null){
        var productAuction = {bid: req.body.price, user: req.user.id};
        Product.findOneAndUpdate({_id: req.query.num}, {$max: {startPrice: req.body.price}, $push:{auction: productAuction}}, function(err, product){
          var userAuction = {bid: req.body.price, product: req.query.num};
          User.findOneAndUpdate({_id: req.user._id}, {$push:{auction: userAuction}}, function(err, user){
            res.redirect(`/cpuPost?num=${req.query.num}`);
          });
        });
      }
      res.redirect(`/cpuPost?num=${req.query.num}`);
    });
  });
});

router.patch('/update', function (req, res, next) {
  Product.findOneAndUpdate({_id: req.body.id}, {Topic: req.body.title, Content: req.body.content, type: req.body.component}, function(err, result){
    res.redirect(`/cpuPost?type=${req.body.component}&num=${req.body.id}`);
  });
});

router.delete('/delete', function (req, res, next) {
  Product.findOneAndRemove({_id: req.query.num}, function(err, result){
    res.redirect(`/shop?type=${req.body.type}&page=1`);
  });
});

module.exports = router;
