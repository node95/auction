var express = require('express');
var User = require('../schemas/user');
const bcrypt = require('bcrypt');
const saltRounds = 10;

var router = express.Router();

router.post('/process', function (req, res, next) {
  const regid = /^[A-Za-z0-9]{4,10}$/;
  const regpwd = /^(?=.*?[a-zA-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,20}$/;
  const regmail = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
  const regpnum = /^010-\d{3,4}-\d{4}$/;

  if(req.body.password !== req.body.password2) {
    req.session.flash.error = ['비밀번호가 일치하지 않습니다.'];
    return req.session.save(function(err) {
      return res.redirect('/register');
    });
  }
  else if(false === regid.test(req.body.id)) {
    req.session.flash.regid = ['아이디 양식에 맞지 않습니다.'];
    return req.session.save(function(err) {
      return res.redirect('/register');
    });
  }
  else if(false === regpwd.test(req.body.password)) {
    req.session.flash.regpwd = ['비밀번호 양식에 맞지 않습니다.'];
    return req.session.save(function(err) {
      return res.redirect('/register');
    });
  }
  else if(false === regmail.test(req.body.email_address)) {
    req.session.flash.regmail = ['이메일 양식에 맞지 않습니다.'];
    return req.session.save(function(err) {
      return res.redirect('/register');
    });
  }
  else if(false === regpnum.test(req.body.phone_number)){
    req.session.flash.regpnum = ['핸드폰 번호 양식에 맞지 않습니다.'];
    return req.session.save(function(err) {
      return res.redirect('/register');
    });
  }
  User.find({}, function(err, user){
    user.forEach(function(user){
      if(user.userId === req.body.id){
        req.session.flash.id = ['중복된 아이디가 존재합니다.'];
        return req.session.save(function(err) {
          return res.redirect('/register');
        });
      }
      else if(user.userEmail === req.body.email_address){
        req.session.flash.email = ['중복된 이메일이 존재합니다.'];
        return req.session.save(function(err) {
          return res.redirect('/register');
        });
      }
      else if(user.userPhoneNum === req.body.phone_number){
        req.session.flash.phone = ['중복된 번호가 존재합니다.'];
        return req.session.save(function(err) {
          return res.redirect('/register');
        });
      }
      else if(user.userNickname === req.body.nickname){
        req.session.flash.nickname = ['중복된 닉네임이 존재합니다.'];
        return req.session.save(function(err) {
          return res.redirect('/register');
        });
      }
    });
  });
  bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
    const user = new User({
      userId: req.body.id,
      userPwd: hash,
      userAddr: req.body.street_address,
      userName: req.body.name,
      userDate: req.body.date,
      userGender: req.body.gender,
      userEmail: req.body.email_address,
      userPhoneNum: req.body.phone_number,
      userNickname: req.body.nickname
    });
    user.save()
      .then((result) => {
        res.redirect('/');
      })
      .catch((err) => {
        next(err);
      });
  });
});

module.exports = router;
