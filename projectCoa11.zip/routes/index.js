var express = require('express');
var router = express.Router();
var moment = require('moment');
var User = require('../schemas/user');
var Post = require('../schemas/post');
var Product = require('../schemas/product');
var async = require('async');

/* GET home page. */
router.get('/blog', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('blog.ejs', { loginStatus: loginStatus});
});

router.get('/mypage', function(req, res, next) {
  var loginstatus = req.isAuthenticated();
  res.render('mypage.ejs', {loginStatus: loginstatus, user: req.user, moment});
});

router.post('/myUpdate', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  const Users = req.user;
  User.findOne({_id: req.query.num}, function(err, user){
    res.render('mypageUpdate.ejs', { loginStatus: loginStatus,
    users: Users.userId,
    usersName: Users.userName, user: user});
  });
});

router.get('/contact', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('contact.ejs', { loginStatus: loginStatus});
});

router.get('/', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('index.ejs', { loginStatus: loginStatus});
});

router.get('/register', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('register.ejs', { loginStatus: loginStatus, message: req.flash()});
});

router.get('/post', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  let authorCheck = false;
  Post.findOneAndUpdate({_id: req.query.num}, {$inc:{postHits: +1}}).populate('postComments.author', 'userNickname').exec(function(err, post){
      if(req.user !== undefined){
        if(req.user._id.toString() === post.postId.toString()) {
          authorCheck = true;
        }
      }
      res.render('noticePost.ejs', { loginStatus: loginStatus, post: post, moment, authorCheck: authorCheck, user: req.user});
  });
});

router.get('/login', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('login.ejs', { loginStatus: loginStatus, message: req.flash()});
});

router.get('/shop', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  var page = Math.max(1, req.query.page);
  var limit = 9;
  var search = createSearch2(req.query);

  async.waterfall([function(callback){
      Product.countDocuments(search.findPost,function(err,count){
        if(err) callback(err);
        skip = (page-1)*limit;
        maxPage = Math.ceil(count/limit);
        callback(null, skip, maxPage, count);
      });
    },function(skip, maxPage, count, callback){
      Product.find(search.findPost).sort({"Date": -1}).skip(skip).limit(limit).exec(function (err, product) {
        if(err) callback(err);
        return res.render("shop.ejs",{
          loginStatus: loginStatus, products: product, page:page, maxPage:maxPage, moment, count: count, type:req.query.type
        });
      });
    }],function(err){
      if(err) return res.json({success:false, message:err});
    });
});

router.get('/cpu', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('cpu.ejs', { loginStatus: loginStatus});
});

router.get('/cpuPost', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  let authorCheck = false;
  Product.findOneAndUpdate({_id: req.query.num}, {$inc:{Hits: +1}}).exec(function(err, product){
      let finishTime = product.finishTime.getTime();
      if(req.user !== undefined){
        if(req.user._id.toString() === product.Id.toString()) {
          authorCheck = true;
        }
      }
      res.render('cpuPost.ejs', { loginStatus: loginStatus, product: product, moment,
        authorCheck: authorCheck, user: req.user, finishTime: finishTime, type: req.query.type});
  });
});

router.get('/notice', function(req,res){
  var loginStatus = req.isAuthenticated();
  var page = Math.max(1, req.query.page);
  var limit = 10;
  var search = createSearch(req.query);

  async.waterfall([function(callback){
      Post.countDocuments(search.findPost,function(err,count){
        if(err) callback(err);
        skip = (page-1)*limit;
        maxPage = Math.ceil(count/limit);
        callback(null, skip, maxPage);
      });
    },function(skip, maxPage, callback){
      Post.find(search.findPost).sort({"postDate": -1}).skip(skip).limit(limit).exec(function (err,posts) {
        if(err) callback(err);
        return res.render("notice.ejs",{
          loginStatus: loginStatus, posts:posts, user:req.user, page:page, maxPage:maxPage, moment, type:req.query.type
        });
      });
    }],function(err){
      if(err) return res.json({success:false, message:err});
    });
});

router.get('/write', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  res.render('write.ejs', { loginStatus: loginStatus, user:req.user.userId});
});

router.post('/update', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  Post.findOne({_id: req.query.num}, function(err, post){
    res.render('noticeUpdate.ejs', { loginStatus: loginStatus, post:post});
  });
});

router.post('/productUpdate', function(req, res, next) {
  var loginStatus = req.isAuthenticated();
  Product.findOne({_id: req.query.num}, function(err, product){
    res.render('productUpdate.ejs', { loginStatus: loginStatus, product: product});
  });
});

function createSearch(queries){
  var findPost = {postType:queries.type};
  if(queries.searchType && queries.searchText){
    var searchTypes = queries.searchType.split(",");
    var postQueries = [];
    if(searchTypes.indexOf("postTopic")>=0){
      postQueries.push({ postTopic : { $regex : new RegExp(queries.searchText, "i") } });
    }
    if(searchTypes.indexOf("postContent")>=0){
      postQueries.push({ postContent : { $regex : new RegExp(queries.searchText, "i") } });
    }
    if(postQueries.length > 0) findPost = {postType:queries.type, $or:postQueries};
  }
  return { searchType:queries.searchType, searchText:queries.searchText,
    findPost:findPost};
}

function createSearch2(queries){
  var findPost = {type:queries.type};
  if(queries.searchType && queries.searchText){
    var searchTypes = queries.searchType.split(",");
    var postQueries = [];
    if(searchTypes.indexOf("postTopic")>=0){
      postQueries.push({ Topic : { $regex : new RegExp(queries.searchText, "i") } });
    }
    if(searchTypes.indexOf("postContent")>=0){
      postQueries.push({ Content : { $regex : new RegExp(queries.searchText, "i") } });
    }
    if(postQueries.length > 0) findPost = {type:queries.type, $or:postQueries};
  }
  return { searchType:queries.searchType, searchText:queries.searchText,
    findPost:findPost};
}

module.exports = router;
