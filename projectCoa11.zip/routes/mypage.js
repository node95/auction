var express = require('express');
const User = require('../schemas/user');

var router = express.Router();

router.patch('/update', function (req, res, next) {
  User.findOneAndUpdate({_id: req.body.id}, {userEmail: req.body.email_address, userPhoneNum: req.body.phone_number,
  userAddr: req.body.street_address, userNickname: req.body.nickname}, function(err, result){
    res.redirect(`/mypage`);
  });
});

module.exports = router;
