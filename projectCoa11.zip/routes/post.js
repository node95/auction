var express = require('express');
var Post = require('../schemas/post');
const multer = require('multer');
const path = require('path');
const Product = require('../schemas/product');
const moment = require('moment-timezone');
const dateKorea = moment.tz(Date.now(), "Asia/Seoul");

var router = express.Router();

router.post('/comments', function (req, res, next) {
  var newComment = {content: req.body.comment, author: req.query.user};
  Post.findOneAndUpdate({_id: req.query.num}, {$push:{postComments: newComment}}, function(err, result){
    res.redirect(`/post?num=${req.query.num}`);
  });
});

router.delete('/comments', function (req, res, next) {
  Post.findOneAndUpdate({_id: req.query.num}, {$pull:{postComments:{_id:req.query.commentId}}}, function(err, result){
    res.redirect(`/post?num=${req.query.num}`);
  });
});

// img post
const upload = multer({
  storage: multer.diskStorage({
    destination(req, file, cb) {
      cb(null, 'public/img/uploads/');
    },
    filename(req, file, cb) {
      const ext = path.extname(file.originalname);
      cb(null, path.basename(file.originalname, ext) + Date.now() + ext);
    },
  }),
  limits: { fileSize: 10000000 },
});

router.post('/upload', upload.single('imgFile'), (req, res) => {
  var ms = Number(req.body.finish_time);
  ms *= 3600 * 1000;
  ms += Number(dateKorea);
  var date = new Date(ms);

  const imgpost = new Product({
    Id: req.user._id,
    img: req.file.filename,
    Topic: req.body.title,
    Content: req.body.content,
    Writer: req.user.userNickname,
    startPrice: req.body.start_price,
    finishTime: date,
    type: req.body.component
  });
  imgpost.save()
    .then((result) => {
      res.status(201).json(result);
    })
    .catch((err) => {
      res.redirect('/contact');
    });
   res.redirect(`/shop?type=${req.body.component}&page=1`);
});

// post
router.post('/process', function (req, res, next) {
  const post = new Post({
    postId: req.user._id,
    postTopic: req.body.title,
    postContent: req.body.content,
    postWriter: req.user.userNickname,
    postType: req.body.component
  });
  post.save()
    .then((result) => {
      res.redirect(`/notice?type=${req.body.component}&page=1`);
    })
    .catch((err) => {
      next(err);
    });
});

router.patch('/update', function (req, res, next) {
  Post.findOneAndUpdate({_id: req.body.id}, {postTopic: req.body.title, postContent: req.body.content}, function(err, result){
    res.redirect(`/post?num=${req.body.id}`);
  });
});

router.delete('/delete', function (req, res, next) {
  Post.findOneAndRemove({_id: req.query.num}, function(err, result){
    res.redirect('/notice?page=1');
  });
});

module.exports = router;
