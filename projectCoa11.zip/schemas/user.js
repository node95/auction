const mongoose = require('mongoose');
const moment = require('moment-timezone');
const dateKorea = moment.tz(Date.now(), "Asia/Seoul");

const { Schema } = mongoose;
const userSchema = new Schema({
  userId: {
    type: String,
    required: true,
  },
  userPwd: {
    type: String,
    required: true,
  },
  userAddr: {
    type: String,
    required: true,
  },
  userName: {
    type: String,
    required: true
  },
  userDate: {
    type: Date,
    required: true
  },
  userGender: {
    type: String,
    required: true
  },
  userEmail: {
    type: String,
    required: true,
  },
  userPhoneNum: {
    type: String,
    required: true
  },
  userNickname: {
    type: String,
    required: true
  },
  auction: [{
    bid: {type: Number, required: true},
    product: {type: Schema.Types.ObjectId, ref: 'Product', required: true},
    success: {type: Boolean, default: false},
    finished: {type: Boolean, default: false},
    createAt: {type: Date, default: dateKorea}
  }]
});

module.exports = mongoose.model('User', userSchema);
