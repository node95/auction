const mongoose = require('mongoose');
const moment = require('moment-timezone');
const dateKorea = moment.tz(Date.now(), "Asia/Seoul");

const { Schema } = mongoose;
const userPost = new Schema({
  postId: {
    type: Schema.Types.ObjectId,
    required: true,
    ref: 'User'
  },
  postTopic: {
    type: String,
    required: true
  },
  postContent: {
    type: String,
    required: true
  },
  postWriter: {
    type: String,
    required: true
  },
  postDate: {
    type: Date,
    default: dateKorea,
    required: true
  },
  postType: {
    type: Number,
    required: true
  },
  postHits: {
    type: Number,
    required: true,
    default: 0
  },
  postComments: [{
    content: {type: String, required: true},
    author: {type: Schema.Types.ObjectId, ref: 'User', required: true},
    createAt: {type: Date, default: dateKorea}
  }]
});

module.exports = mongoose.model('Post', userPost);
