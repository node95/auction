const mongoose = require('mongoose');
const moment = require('moment-timezone');
const dateKorea = moment.tz(Date.now(), "Asia/Seoul");

const { Schema } = mongoose;
const imgPost = new Schema({
  Id: {
    type: Schema.Types.ObjectId,
    required: true,
    ref: 'User'
  },
  img: {
    type: String,
    required: true
  },
  Topic: {
    type: String,
    required: true
  },
  Content: {
    type: String,
    required: true
  },
  Writer: {
    type: String,
    required: true
  },
  Date: {
    type: Date,
    default: dateKorea,
    required: true
  },
  startPrice: {
    type: Number,
    required: true
  },
  finishTime: {
    type: Date,
    required: true
  },
  Hits: {
    type: Number,
    required: true,
    default: 0
  },
  type: {
    type: Number,
    required: true
  },
  auction: [{
    bid: {type: Number, required: true},
    user: {type: Schema.Types.ObjectId, ref: 'User', required: true},
    createAt: {type: Date, default: dateKorea}
  }]
});

module.exports = mongoose.model('Product', imgPost);
