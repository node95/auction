var express = require('express');
var logger = require('morgan');
var bodyParser = require('body-parser');
var path = require('path');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var passport = require('passport');
var FileStore = require('session-file-store')(session);
var methodOverride = require('method-override');
var flash = require('connect-flash');
var schedule = require('node-schedule');
var User = require('./schemas/user');
var Product = require('./schemas/product');
var compression = require('compression');

var connect = require('./schemas');
var passportConfig = require('./passport');

var indexRouter = require('./routes/index');
var user = require('./routes/users');
var login = require('./routes/login');
var logout = require('./routes/logout');
var post = require('./routes/post');
var product = require('./routes/product');
var mypage = require('./routes/mypage');

var app = express();
connect();
passportConfig(passport);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride("_method"));
app.use(cookieParser('hi'));
app.use(session({
  secret: 'hi',
  resave: false,
  saveUninitialized: true,
  store: new FileStore(),
  cookie: {
    httpOnly: true,
    secure: false,
  }
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
app.use(compression());

app.use('/', indexRouter);
app.use('/user', user);
app.use('/login', login);
app.use('/logout', logout);
app.use('/post', post);
app.use('/product', product);
app.use('/mp', mypage);

app.use(function(request, response, next){
  response.status(404).send('Sorry cant find that!');
});

app.use(function(error, request, response, next){
  console.error(error.stack);
  response.status(500).send('Something broke!');
});

app.listen(3000, function(){
  Product.find({}, function(err, product){
    var j = [];
    var current = new Date().getTime();
    const term = 1000 * 60 * 5;
    product.forEach(function(product){
       let finish = product.finishTime.getTime();
       if((current - term) < finish && finish < (current + term)){
        j.push(product);
       }
    });
    for(let i = 0; i < j.length; i++){
      if(j[i].auction[0] !== undefined){
        let sort = j[i].auction.sort(function(a, b){
          return a.bid < b.bid ? 1 : a.bid > b.bid ? -1 : 0;
        });
        var a = schedule.scheduleJob(j[i].finishTime, function(){
          User.update({"auction.product": j[i]._id}, {$set: {"auction.$.finished": true}}, {multi: true}, function(err, result1){
            User.findOneAndUpdate({_id: sort[0].user, "auction.product": j[i]._id}, {$set: {"auction.$.success": true}}, function(err, result2){
            });
          });
        });
      }
    }
  });
  console.log('Example app listening on port 3000!');
});
